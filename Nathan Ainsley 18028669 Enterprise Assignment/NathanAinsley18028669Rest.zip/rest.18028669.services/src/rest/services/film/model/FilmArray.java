package rest.services.film.model;
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(namespace = "model")
public class FilmArray {
	@XmlElementWrapper(name = "FILMS")
	@XmlElement(name="film")
	
	
	private ArrayList<Film> filmsList;
	
	public void setFilmObj(ArrayList<Film> filmsFromDAO) {
		this.filmsList = filmsFromDAO;
	}
	public ArrayList<Film> getFilmList() {
		return filmsList;
	}
	/*
	 * public void setFilmList(ArrayList<Film> filmsFromDAO) { // TODO
	 * Auto-generated method stub
	 * 
	 * }
	 */


}
