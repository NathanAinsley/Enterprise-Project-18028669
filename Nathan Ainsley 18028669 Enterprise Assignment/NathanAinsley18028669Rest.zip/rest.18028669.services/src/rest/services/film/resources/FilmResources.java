package rest.services.film.resources;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;


import rest.services.film.model.Film;
import rest.services.film.dao.FilmDAO;

//Will map the resource to the URL todos
@Path("/films")

public class FilmResources {
		FilmDAO fd = new FilmDAO();
		// Allows to insert contextual objects into the class,
		// e.g. ServletContext, Request, Response, UriInfo
		@Context
		UriInfo uriInfo;
		@Context
		Request request;
		
		//DO NOT TOUCH - FILMS TO BROWSER WORKS
		// Return the list of films to the user in the browser
		@GET
		@Produces(MediaType.TEXT_XML)
		public ArrayList<Film> getFilmsBrowser() {
			ArrayList<Film> films = new ArrayList<Film>();
			films.addAll(fd.getAllFilms());
			return films;
		}
		
		//DO NOT TOUCH - FILMS TO APPLICATION WORKS
		// Return the list of films for applications
		@GET
		@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
		public ArrayList<Film> getFilms() {
			ArrayList<Film> films = new ArrayList<Film>();
			films.addAll(fd.getAllFilms());
			return films;
		}
		
		//DO NOT TOUCH - COUNT WORKS
		// retuns the number of films 
		// Use http://localhost:8080/rest.18028669.services/rest/films/count 
		// to get the total number of records
		  
		@GET
		@Path("count")
		@Produces(MediaType.TEXT_PLAIN) 
		public String getCount() { 
			  int count = fd.getAllFilms().size(); 
			  return String.valueOf(count); 
		}
		 
		
		
		//DO NOT TOUCH - ADD FILM WORKS	
		@POST
		@Produces(MediaType.TEXT_HTML)
		@Consumes(MediaType.APPLICATION_FORM_URLENCODED) 
		public void newFilm(
							@FormParam("id") int id,
							@FormParam("title") String title,
							@FormParam("year") int year,
							@FormParam("director") String director,
							@FormParam("stars") String stars,
							@FormParam("review") String review,
							@Context HttpServletResponse servletResponse) throws IOException { 
			System.out.println(id+title+ year+ director+ stars+ review);
			fd.insertFilm(id,title, year, director, stars, review);
			servletResponse.sendRedirect("../create_film.html"); 
			}

		  
			
			  
			  
			 
		 
		
		
		
		// Defines that the next path parameter after films is
		// treated as a parameter and passed to the TodoResources
		// Allows to type http://localhost:8080/rest.18028669.services/rest/films/1
		// 1 will be treated as parameter todo and passed to TodoResource
		
		@Path("{films}")
		public FilmResource getFilmID(
			@PathParam("films") String id) {
			return new FilmResource(uriInfo, request, id);
		}

}
