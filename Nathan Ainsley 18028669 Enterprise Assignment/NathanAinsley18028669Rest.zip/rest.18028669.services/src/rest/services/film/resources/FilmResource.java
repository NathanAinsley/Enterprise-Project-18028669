package rest.services.film.resources;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.xml.bind.JAXBElement;



import rest.services.film.dao.FilmDAO;
import rest.services.film.model.Film;

public class FilmResource {

	@Context
	UriInfo uriInfo;
	@Context
	Request request;
	String id;
	FilmDAO fd = new FilmDAO();

	public FilmResource(UriInfo uriInfo, Request request, String id) {
		this.uriInfo = uriInfo;
		this.request = request;
		this.id = id;
	}
	
	//DO NOT TOUCH - SEARCH ID WORKS
	// Application integration
	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Film getFilmID() {
		int ID = Integer.parseInt(id);
		Film film = fd.getFilmByID(ID);
		if (film == null)
			throw new RuntimeException("Get: film with ID " + id + " not found");
		return film;
	}
	
	// For the browser
	@GET
	@Produces(MediaType.TEXT_XML)
	public Film getFilmHTML() {
		int ID = Integer.parseInt(id);
		Film film = fd.getFilmByID(ID);
		if (film == null)
			throw new RuntimeException("Get: film with ID " + id + " not found");
		return film;
	}

	
	//DO NOT TOUCH - DELETE WORKS
	@DELETE
	public void deleteTodo() {
		int ID = Integer.parseInt(id);
		int c = fd.deleteFilm(ID);
		if(c==0)
			throw new RuntimeException("Delete: Todo with " + id + " not found");
	}
	 
	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	public Response putTodo(JAXBElement<Film> Film)  {
		Film c = Film.getValue();
		
		return putAndGetResponse(c);
		
	}
	
	private Response putAndGetResponse(Film film) {
		Response res;
		Film evalFilm = fd.getFilmByID(film.getId());
		if(evalFilm != null) {
				res = Response.noContent().build();
		} else {
				res = Response.created(uriInfo.getAbsolutePath()).build();
		}
		fd.updateFilm(film.getId(), film.getTitle(), film.getYear(), film.getDirector(), film.getStars(), film.getReview());
		
		return res;
	}

}
