package rest.services.film.dao;
import java.util.ArrayList;

import rest.services.film.model.Film;

import java.sql.*;


public class FilmDAO {
	
	Film oneFilm = null;
	Connection conn = null;
    Statement stmt = null;
    String user = "ainsleyn";
    String password = "Flac7term";
    // Note none default port used, 6306 not 3306
    String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/"+user;

	public FilmDAO() {}

	
	private void openConnection(){
		// loading jdbc driver for mysql
		try{
		    Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch(Exception e) { System.out.println(e); }

		// connecting to database
		try{
			// connection string for demos database, username demos, password demos
 			conn = DriverManager.getConnection(url, user, password);
		    stmt = conn.createStatement();
		} catch(SQLException se) { System.out.println(se); }	   
    }
	private void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Film getNextFilm(ResultSet rs){
    	Film thisFilm=null;
		try {
			thisFilm = new Film(
					rs.getInt("id"),
					rs.getString("title"),
					rs.getInt("year"),
					rs.getString("director"),
					rs.getString("stars"),
					rs.getString("review"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return thisFilm;		
	}
	
	
	
	
   public ArrayList<Film> getAllFilms(){
	   
		ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();
		
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    	allFilms.add(oneFilm);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
   }
   
   public int insertFilm(int id, String title , int year, String director, String stars, String Review) {
	   int success=0;
	   openConnection();
	   
	   try{
		    String selectSQL = ("Insert into films " + "Values ("+id+", '"+title+"', "+year+", '"+director+"', '"+stars+"', '"+Review+"');");
		    stmt.executeUpdate(selectSQL);
		    stmt.close();
		    closeConnection();
		    success = 1;
		} catch(SQLException se) { System.out.println(se); }
	   
	   return success;
   }
   				
   public int updateFilm(int id, String title , int year, String director, String stars, String Review) {
	   int success=0;
	   openConnection();
	   
	   try{
		    String selectSQL = ("Update films " + "Set title ='" + title + "', year ='" + year +"', director='" + director + "', stars='" + stars + "', review='" + Review + "' Where id ='" +id+"';");
		    stmt.executeUpdate(selectSQL);
		    stmt.close();
		    closeConnection();
		    success = 1;
		} catch(SQLException se) { System.out.println(se); }
	   
	   return success;
   }
   
   public int deleteFilm(int id) {
	   int success=0;
	   openConnection();
	   
	   try{
		    String selectSQL = ("Delete from films where id="+id);
		    stmt.executeUpdate(selectSQL);
		    stmt.close();
		    closeConnection();
		    success = 1;
		} catch(SQLException se) { System.out.println(se); }
	   
	   return success;
   }

   public Film getFilmByID(int id){
	   
		openConnection();
		oneFilm=null;
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films where id="+id;
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return oneFilm;
   }
   
   public Film getFilmByName(String title){
	   
	   title = "'%"+title+"%'";
	   ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();
		
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films where title like"+title;
		    System.out.println(selectSQL);
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }
		return oneFilm;

	   
  }
   
public ArrayList<Film> getFilmByYear(String year){
	   
	year = "'%"+year+"%'";
		   ArrayList<Film> allFilms = new ArrayList<Film>();
			openConnection();
			
		    // Create select statement and execute it
			try{
			    String selectSQL = "select * from films where year like"+year;
			    System.out.println(selectSQL);
			    ResultSet rs1 = stmt.executeQuery(selectSQL);
		    // Retrieve the results
			    while(rs1.next()){
			    	oneFilm = getNextFilm(rs1);
			    	allFilms.add(oneFilm);
			   }

			    stmt.close();
			    closeConnection();
			} catch(SQLException se) { System.out.println(se); }

		   return allFilms;
	  }
   
public ArrayList<Film> getFilmByDirector(String director){
	   
		director = "'%"+director+"%'";
		ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();
		
	    // Create select statement and execute it
		try{
			String selectSQL = "select * from films where director like"+director;
		    System.out.println(selectSQL);
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    	allFilms.add(oneFilm);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
  }

public ArrayList<Film> getFilmByStars(String stars){
	   
	stars = "'%"+stars+"%'";
	ArrayList<Film> allFilms = new ArrayList<Film>();
	openConnection();
	
    // Create select statement and execute it
	try{
		String selectSQL = "select * from films where stars like"+stars;
	    System.out.println(selectSQL);
	    ResultSet rs1 = stmt.executeQuery(selectSQL);
    // Retrieve the results
	    while(rs1.next()){
	    	oneFilm = getNextFilm(rs1);
	    	allFilms.add(oneFilm);
	   }

	    stmt.close();
	    closeConnection();
	} catch(SQLException se) { System.out.println(se); }

   return allFilms;
}
   
   
   
   
}
