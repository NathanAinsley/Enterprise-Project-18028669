package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.FilmDAOHib;

/**
 * Servlet implementation class DeleteFilm
 */
@WebServlet("/DeleteFilm")
public class DeleteFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Delete starting...");
		//creates new FilmDAO object using the singleton DP
		FilmDAOHib Hib = FilmDAOHib.getFilmDAOHibobject();
		//sets the parameter id to String variable
		String id = request.getParameter("id");
		System.out.println("Film to be deleted: " + id);
		//debug prints the id to console
		System.out.println(id);
		//parses string id to Integer ID
		int ID = Integer.parseInt(id);
		//sets success variable, runs the deleteFilm(id) class in the DAO
		int Success = Hib.deleteFilm(ID);
		System.out.println("Film "+id+ " deleted");
		//creates the PrintWriter
		PrintWriter out = response.getWriter();
		//if delete was successfull return success string
		if (Success == 1) {
			out.print("Successfully Deleted Film");
		}//closes if
		//else return error string
		else {
			out.print("Error Deleting Film");
		}//closes else
	}//closes doGet()
}//closes class
