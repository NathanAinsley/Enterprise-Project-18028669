package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import model.Film;
import model.FilmDAOHib;

@WebServlet("/InsertFilm")
public class InsertFilm extends HttpServlet {
	//private static final String Films_XML = "./WEB-INF/results/Films-jaxb.xml";
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Insert starting...");
		//creates new FilmDAO object using the singleton DP
		FilmDAOHib Hib = FilmDAOHib.getFilmDAOHibobject();
		//collects all the parameters and sets them to variables
		String id = request.getParameter("id");
		int ID = Integer.parseInt(id);
		String Title = request.getParameter("title");
		String year = request.getParameter("year");
		int Year = Integer.parseInt(year);
		String Director = request.getParameter("director");
		String Stars = request.getParameter("stars");
		String Review = request.getParameter("review");
		//sets success value to false
		int Success = 0;
		//creates PrintWriter
		PrintWriter out = response.getWriter();
		//creates an arraylist called IDMATCH and searches for the ID that the user wants to use for the new record
		System.out.println("IDMATCH starting...");
		ArrayList<Film> IDMATCH = Hib.getFilmsByID(ID);
		//if statment for if the Id wanted matches an existing record, if the size of the array is 0 then there is no match
		if (IDMATCH.size() == 0) {
			System.out.println("No Film with id " + ID + " Found in database, clear to insert record...");
			//runs the addFilm() function in the DAO and returns a success value
			Success = Hib.addFilm(ID, Title, Year, Director, Stars, Review);
			  //if the operation was successful then it will print out a msg to the console and return the msg to the user to print to the webpage
			  if (Success == 1) {
				  //returns msg to user and console
				  out.print("Successfully added film: (ID) "+ID+" (Title) "+Title);
				  System.out.println("Successfully added film: (ID) "+ID+" (Title) "+Title);
			  }//close if (Success == 1) statment
		}//close (IDMATCH.size() == 0) statment
		else {
			//else print out an error msg to user and console
			out.print("Error, ID: "+ID+" Is already in use, please try a different ID");
			System.out.println("Error, ID: "+ID+" Is already in use, please try a different ID");
		}//close else statment	
	}//close doPost()
}//close class

