package controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Film;
import model.FilmDAOHib;
import view.Formatter;

@WebServlet("/Search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Search starting...");
		//creates new FilmDAO object using the singleton DP
		FilmDAOHib Hib = FilmDAOHib.getFilmDAOHibobject();
		//collects all the parameters and sets them to variables
		String id = request.getParameter("filmid");
		String title = request.getParameter("filmname");
		String year = request.getParameter("filmyear");
		String director = request.getParameter("filmdirector");
		String stars = request.getParameter("filmstars");
		ArrayList<Film> filmsFromDAO  = new ArrayList<Film>();
		//Yes ID | No Everything else
		if (id != null && title == null && year == null && director == null && stars == null ) {
			int ID = Integer.parseInt(id);
			filmsFromDAO.addAll(Hib.getFilmsByID(ID));
			System.out.println(id);
			System.out.println("Films Loaded from database");
		}//close if
		//Yes title | No Everything else
		else if (id == null && title != null && year == null && director == null && stars == null ) {
			System.out.println(title);
			filmsFromDAO = (Hib.getFilmsByTitle(title));
			System.out.println("Films Loaded from database");
		}//close else if
		//Yes Year | No Everything else
		else if (id == null && title == null && year != null && director == null && stars == null ) {
			System.out.println(year);
			filmsFromDAO = (Hib.getFilmsByYear(year));
			System.out.println("Films Loaded from database");
		}//close else if
		//Yes director | No Everything else
		else if (id == null && title == null && year == null && director != null && stars == null ) {
			System.out.println(director);
			filmsFromDAO = (Hib.getFilmsByDirector(director));
			System.out.println("Films Loaded from database");
		}//close else if
		//Yes director | No Everything else
		else if (id == null && title == null && year == null && director == null && stars != null ) {
			System.out.println(stars);
			filmsFromDAO = (Hib.getFilmsByStars(stars));
			System.out.println("Films Loaded from database");
		}//close else if
		//sets the response object
	    response.setHeader("Cache-Control", "no-cache");
	    response.setHeader("Pragma", "no-cache");
	    request.setAttribute("films", filmsFromDAO);
	    //retrieves the format of data
	    String format = request.getParameter("format");
	    //debug prints to console
	    System.out.println("Format: " + format);
	    System.out.println(filmsFromDAO.size() + " Records found in database that match...");
	    //if statment for if the format is xml
	    if ("xml".equals(format)) {
	    	PrintWriter out = response.getWriter();
	    	response.setContentType("text/xml");
	    	//calls the formatter class to format the data into xml
	    	ByteArrayOutputStream baos = Formatter.FormatXML(filmsFromDAO);
	    	out.print(baos);
	    }//closes if (xml) statment
	    //if statment for if the format is string
	    else if ("string".equals(format)){
	    	//sets response conetent type to html for string
	    	response.setContentType("text/html"); 
			PrintWriter out = response.getWriter();
			//for loop to iterate through the film objects
			for (Film film : filmsFromDAO) {
				String record = Formatter.FormatSTRING(film);
				//returns the string to the user
				out.println(record);
			}//close for loop
	    }//close else if loop
	    //default return is json
	    else  {
	    	//sets response content type to html for json
	    	response.setContentType("text/html"); 
			PrintWriter out = response.getWriter();
			String jsonResult = Formatter.FormatJSON(filmsFromDAO);
			out.println(jsonResult);
		}//closes else statment
	  }//closes doGet()
}

