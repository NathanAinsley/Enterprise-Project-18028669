package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.FilmDAOHib;

/**
 * Servlet implementation class UpdateFilm
 */
@WebServlet("/UpdateFilm")
public class UpdateFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Update starting...");
		//creates new FilmDAO object using the singleton DP
		FilmDAOHib Hib = FilmDAOHib.getFilmDAOHibobject();
		//grabs the parameter id and sets it to a peramiter
		String id = request.getParameter("id");
		//parses the string id into an integer ID
		int ID = Integer.parseInt(id);
		//grabs the parameter title and sets it to a peramiter
		String Title = request.getParameter("title");
		//grabs the parameter year and sets it to a peramiter
		String year = request.getParameter("year");
		//parses the string year into an integer Year
		int Year = Integer.parseInt(year);
		//grabs the parameter director and sets it to a peramiter
		String Director = request.getParameter("director");
		//grabs the parameter stars and sets it to a peramiter
		String Stars = request.getParameter("stars");
		//grabs the parameter review and sets it to a peramiter
		String Review = request.getParameter("review");
		//sets the success value to false
		int Success = 0;
		//creates the printwriter to return the Success value is wanted
		PrintWriter out = response.getWriter();
		//calls the updateFilm method within the DAO passing the values to be updated
		Success = Hib.updateFilm(ID, Title , Year, Director, Stars, Review);
		if(Success == 1) {
			System.out.println("Update Successful");
		}
		else{
			System.out.println("Update Failed");
		}
		//returns the success varaible
		out.print(Success);
	}//closes doPost()
}//closes class
