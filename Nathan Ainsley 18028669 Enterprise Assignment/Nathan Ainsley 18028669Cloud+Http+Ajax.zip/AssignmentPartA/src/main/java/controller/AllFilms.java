package controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Film;
import model.FilmDAOHib;
import view.Formatter;

/**
 * Servlet implementation class Control
 */
@WebServlet("/AllFilms")
public class AllFilms extends HttpServlet {
	//private static final String Films_XML = "./WEB-INF/results/Films-jaxb.xml";
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AllFilms starting...");
		//creates new FilmDAO object using the singleton DP
		FilmDAOHib Hib = FilmDAOHib.getFilmDAOHibobject();
		//creates ArrayList to populate with AllFilms
		ArrayList<Film> filmsFromDAO = new ArrayList<Film>();
		//fills ArrayList with films via getter()
		filmsFromDAO = Hib.ListAllFilms();
		System.out.println("Films Loaded from database");
		//sets the response object
	    response.setHeader("Cache-Control", "no-cache");
	    response.setHeader("Pragma", "no-cache");
	    request.setAttribute("films", filmsFromDAO);
	    //retrieves the format of data
	    String format = request.getParameter("format");
	    //debug prints to console
	    System.out.println("Search Format: " + format);
	    System.out.println(filmsFromDAO.size() + " Records found in database that match...");
	    //if statment for if the format is xml
	    if ("xml".equals(format)) {
	    	PrintWriter out = response.getWriter();
	    	response.setContentType("text/xml");
	    	//calls the formatter class to format the data into xml
	    	ByteArrayOutputStream baos = Formatter.FormatXML(filmsFromDAO);
	    	out.print(baos);
	    }//closes if (xml) statment
	    //if statment for if the format is string
	    else if ("string".equals(format)){
	    	//sets response conetent type to html for string
	    	response.setContentType("text/html"); 
			PrintWriter out = response.getWriter();
			//for loop to iterate through the film objects
			for (Film film : filmsFromDAO) {
				String record = Formatter.FormatSTRING(film);
				//returns the string to the user
				out.println(record);
			}//close for loop
	    }//close else if loop
	    //default return is json
	    else  {
	    	//sets response content type to html for json
	    	response.setContentType("text/html"); 
			PrintWriter out = response.getWriter();
			String jsonResult = Formatter.FormatJSON(filmsFromDAO);
			out.println(jsonResult);
		}//closes else statment
	  }//closes doGet()
}
