package view;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.google.gson.Gson;

import model.Film;
import model.FilmArray;

public class Formatter {
	
	public static ByteArrayOutputStream FormatXML(ArrayList<Film> filmsFromDAO) {
		FilmArray filmarray = new FilmArray();
    	//populates the filmArray object with the arraylist
    	filmarray.setFilmObj(filmsFromDAO);
		try {
			//Uses Jaxb to sort the xml data
			JAXBContext context = JAXBContext.newInstance(FilmArray.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			m.marshal(filmarray, baos);
			//returns the xml data to the user
			return baos;
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public static String FormatSTRING(Film film) {
		//creates a string with the seperator of |, this character was chosen as it is unlikely to come up in a film compared to a comma
		String record = (film.getId() + "|" + film.getTitle() + "|" + film.getYear() + "|" + film.getDirector() + "|" + film.getStars() + "|" + film.getReview());
		return record;
	}
	public static String FormatJSON(ArrayList<Film> filmsFromDAO) {
		//creates a new Gson obkect
		Gson gson = new Gson(); 
		String jsonResult;
		//creates a json string with the arraylist of films objects
		jsonResult = gson.toJson(filmsFromDAO);
		//returns the data to the user
		return jsonResult;
	}

}
