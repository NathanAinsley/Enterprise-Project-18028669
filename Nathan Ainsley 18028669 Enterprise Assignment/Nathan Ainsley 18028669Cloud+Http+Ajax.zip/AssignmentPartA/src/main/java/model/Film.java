package model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


//setting the root element for the xml object
@XmlRootElement(name = "film")
//setting the order of data in the xml object
@XmlType(propOrder = { "id", "title", "year", "director","stars","review" })
//creates an entity for hibernate
@Entity
//defines the table
@Table(name="films")
public class Film {
	//constructor for the Film object
	public Film(int id, String title, int year, String director, String stars,String review) {
		super();
		this.id = id;
		this.title = title;
		this.year = year;
		this.director = director;
		this.stars = stars;
		this.review = review;
	}
	//defines as the ID
    @Id
    //defines the table column to id
	@Column(name="id")
   	int id;
  //defines the table column to title
    @Column(name="title")
	String title;
  //defines the table column to year
    @Column(name="year")
	int year;
  //defines the table column to director
    @Column(name="director")
	String director;
  //defines the table column to stars
    @Column(name="stars")
	String stars;
  //defines the table column to review
    @Column(name="review")
	String review;
   	
    //get id, returns the id from the object
	public int getId() {
		return id;
	}
	//sets id for the film object
	public void setId(int id) {
		this.id = id;
	}
	//get title, returns the title from the object
	public String getTitle() {
		return title;
	}
	//sets title for the film object
	public void setTitle(String title) {
		this.title = title;
	}
	//get year, returns the year from the object
	public int getYear() {
		return year;
	}
	//sets year for the film object
	public void setYear(int year) {
		this.year = year;
	}
	//get director, returns the director from the object
	public String getDirector() {
		return director;
	}
	//sets director for the film object
	public void setDirector(String director) {
		this.director = director;
	}
	//get stars, returns the stars from the object
	public String getStars() {
		return stars;
	}
	//sets stars for the film object
	public void setStars(String stars) {
		this.stars = stars;
	}
	//get review, returns the review from the object
	public String getReview() {
		return review;
	}
	//sets review for the film object
	public void setReview(String review) {
		this.review = review;
	}
	
	public Film() {}
	//returns the film object as a string
	@Override
	public String toString() {
		return "Film [id=" + id + ", title=" + title + ", year=" + year
				+ ", director=" + director + ", stars=" + stars + ", review="
				+ review + "]";
	}   
}
