package model;
import java.util.ArrayList;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
public class FilmDAOHib {
	private static SessionFactory factory;	
	//singleton Design patten for the FilmDAOHibobject to mean there is only one to save on resources
	private static FilmDAOHib FilmDAOHibobject;
	private FilmDAOHib() {}
	public static synchronized FilmDAOHib getFilmDAOHibobject() {
		if (FilmDAOHibobject == null) {
			FilmDAOHibobject = new FilmDAOHib();
		}
		return FilmDAOHibobject;
	}
	
	/* Method to return a list of all films in the database*/
	public ArrayList<Film> ListAllFilms() {
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		ArrayList<Film> films = new ArrayList<Film>();
		try {
			tx = session.beginTransaction();
			String hql = "FROM Film";
			films.addAll(session.createQuery(hql).list());
			return films;
			
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return null;
		
	}
	/* Method to Search for a film in the database by id*/
	public ArrayList<Film> getFilmsByID(int id) {
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		ArrayList<Film> films = new ArrayList<Film>();
		try {
			tx = session.beginTransaction();
			String hql = "FROM Film where id="+ id;
			films.addAll(session.createQuery(hql).list());
			return films;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return null;
	}
	/* Method to Search for a film in the database by title*/
	public ArrayList<Film> getFilmsByTitle(String title) {
		title = "'%"+title+"%'";
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		ArrayList<Film> films = new ArrayList<Film>();
		try {
			tx = session.beginTransaction();
			String hql = "FROM Film where title like"+ title;
			films.addAll(session.createQuery(hql).list());
			return films;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return null;
	}
	/* Method to Search for a film in the database by year*/
	public ArrayList<Film> getFilmsByYear(String year) {
		year = "'%"+year+"%'";
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		ArrayList<Film> films = new ArrayList<Film>();
		try {
			tx = session.beginTransaction();
			String hql = "FROM Film where year like "+ year;
			films.addAll(session.createQuery(hql).list());
			return films;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return null;
	}
	/* Method to Search for a film in the database by director*/
	public ArrayList<Film> getFilmsByDirector(String director) {
		director = "'%"+director+"%'";
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		ArrayList<Film> films = new ArrayList<Film>();
		try {
			tx = session.beginTransaction();
			String hql = "FROM Film where director like"+ director;
			films.addAll(session.createQuery(hql).list());
			return films;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return null;
	}
	/* Method to Search for a film in the database by stars*/
	public ArrayList<Film> getFilmsByStars(String stars) {
		stars = "'%"+stars+"%'";
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		ArrayList<Film> films = new ArrayList<Film>();
		try {
			tx = session.beginTransaction();
			String hql = "FROM Film where stars like"+ stars;
			films.addAll(session.createQuery(hql).list());
			return films;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return null;
	}
	/* Method to CREATE a film in the database */
	public Integer addFilm(int id, String title , int year, String director, String stars, String review){
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		int success=0;
		try{
			tx = session.beginTransaction();
			Film newfilm = new Film(id, title, year, director, stars, review);
			session.saveOrUpdate(newfilm);
			tx.commit();
			success = 1;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return success;
	}
	/* Method to Delete a film in the database */
	public int deleteFilm(Integer FilmID){
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		int success=0;
		Session session = factory.openSession();
		Transaction tx = null;
		try{
			tx = session.beginTransaction();
			Film delFilm = (Film)session.get(Film.class, FilmID);
			session.delete(delFilm);
			tx.commit();
			success=1;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return success;
	}
	/* Method to Update a film in the database */
	public Integer updateFilm(int id, String title , int year, String director, String stars, String review){
		try {
			factory = new AnnotationConfiguration().configure().addAnnotatedClass(Film.class).buildSessionFactory();
		}catch(Throwable ex) {
			System.err.println("Failed to create sessionFactory object. " + ex);
			throw new ExceptionInInitializerError(ex);
		}
		Session session = factory.openSession();
		Transaction tx = null;
		int success=0;
		try{
			tx = session.beginTransaction();
			Film editFilm =	(Film)session.get(Film.class,id);
			editFilm.setTitle(title);
			editFilm.setYear(year);
			editFilm.setDirector(director);
			editFilm.setStars(stars);
			editFilm.setReview(review);
			session.update(editFilm);
			tx.commit();
			success=1;
		}catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
		return success;
	}
}
