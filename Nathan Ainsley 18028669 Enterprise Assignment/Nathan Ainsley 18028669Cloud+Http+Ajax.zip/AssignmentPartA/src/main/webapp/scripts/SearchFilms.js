function Search_CustomerTable($resultRegion,SearchType,SearchVal,DataType){
	var format = DataType;
	if(format == "xml"){
		console.log("Search Format is XML");
		Search_xmlCustomerTable($resultRegion,SearchType,SearchVal);
	}
	else if(format == "string"){
		console.log("Search Format is String");
		Search_stringCustomerTable($resultRegion,SearchType,SearchVal);
	}
	//default return is json
	else {
		console.log("Search Format is JSON");
		Search_jsonCustomerTable($resultRegion,SearchType,SearchVal);
	}
}


function Search_xmlCustomerTable(resultRegion,SearchType, SearchVal) {
	console.log("XML TEST bert");
  	var address = "Search";
	var data = makeParamString(SearchType,SearchVal,"xml");
  	$.ajax({
			url: address, 
			data: data,
			success: function(request){showXmlCustomerInfo(request,resultRegion)},
			error: function(){
				alert('error running showCmlCustomerInfo()');
			}//close error function
		})//close ajax
}//close cuntion

function Search_jsonCustomerTable($resultRegion,SearchType, SearchVal) {
  	var address = "Search";
	var data = makeParamString(SearchType, SearchVal , "json");
  	$.ajax({
		url: address, 
		data: data,
		success: function(request){showJsonCustomerInfo(request,$resultRegion)},
		error: function(){
			alert('error running showJsonCustomerInfo()');
		}
	})//close ajax
}

function Search_stringCustomerTable($resultRegion,SearchType,SearchVal) {
  	var address = "Search";
	var data = makeParamString(SearchType,SearchVal,"string");
  	$.ajax({	type: "GET",
		url: address, 
		data: data,
		success: function(request){showStringCustomerInfo(request,$resultRegion)},
		error: function(){
			alert('error running showStringCustomerInfo()');
		}
	})//close ajax
}