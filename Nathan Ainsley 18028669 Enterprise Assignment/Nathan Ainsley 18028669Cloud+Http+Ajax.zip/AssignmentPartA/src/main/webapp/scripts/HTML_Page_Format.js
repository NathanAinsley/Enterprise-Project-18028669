function ADD_MODE(){
	var RUD = document.getElementById("RUD");
	var C = document.getElementById("C(RUD)");
	if (RUD.style.display === "none") {
    RUD.style.display = "block";
	C.style.display = "none";
  } else {
    RUD.style.display = "none";
	C.style.display = "block";
  }
}