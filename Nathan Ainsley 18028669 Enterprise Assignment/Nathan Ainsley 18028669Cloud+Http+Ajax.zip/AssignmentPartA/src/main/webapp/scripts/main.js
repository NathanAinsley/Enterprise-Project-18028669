$(function(){
	var C = document.getElementById("C(RUD)");
	C.style.display = "none";
	
	var $resultRegion = $('#results');
	
	var $FilmID = $('#Add_Film_ID');
	var $FilmTitle = $('#Add_Film_Title');
	var $FilmYear = $('#Add_Film_Year');
	var $FilmDirector = $('#Add_Film_Director');
	var $FilmStars = $('#Add_Film_Stars');
	var $FilmReview = $('#Add_Film_Review');

	
	
	
	
	$('#SearchFilm').on('click',function(){
		console.log("Search for film started");
		var DataType = getValue('data_type');
		var SearchType = getValue('search_type');
		var SearchVal = getValue('search_val');

		//Searching Via Name or ID		
		if(SearchVal != ""){
			$resultRegion.empty();
			Search_CustomerTable($resultRegion,SearchType,SearchVal,DataType)	
		}
		//detecting if user has left both search boxes empty
		else {
			window.alert("Search Box has no value in it, Please enter value to search for film");
			console.log("SearchVal is empty")
		}
		
	})//close click
	$('#AllFilms').on('click',function(){
		
		var DataType = getValue('data_type');
		$resultRegion.empty();
		All_CustomerTable($resultRegion,DataType)
	})//close click
	$('#AddFilm').on('click',function(){
		
		$resultRegion.empty();
		var film = {
			id: $FilmID.val(),
			title: $FilmTitle.val(),
			year: $FilmYear.val(),
			director: $FilmDirector.val(),
			stars: $FilmStars.val(),
			review: $FilmReview.val()
		}		
		var errorTemplate = $('#InsertErrorTemplate').html();
		$.ajax({
			type:'POST',
			url: 'InsertFilm',
			data: film,
			success: function(request) {
				data = {data: request};
				$resultRegion.append(Mustache.render(errorTemplate, data));
			},
			error: function(){
				alert('Error adding film, try another ID');
			}//close error function
		})
	});//close click
	
	$resultRegion.delegate('.remove','click',function(){
		console.log($(this).attr('data-id'));
		var data = "id=" + $(this).attr('data-id');
		var $li = $(this).closest('li');
		$.ajax({
			type:'GET',
			url:'DeleteFilm',
			data:data,
			success: function(request) {
				if(request == "Successfully Deleted Film"){
					$li.remove();
				}
				console.log(request);
			}
		})	
	});//close remove button
		
	$resultRegion.delegate('.editFilm','click',function(){
		var $li = $(this).closest('li');
		$li.find('input.id').val($li.find('span.id').html());
		$li.find('input.title').val($li.find('span.title').html());
		$li.find('input.year').val($li.find('span.year').html());
		$li.find('input.director').val($li.find('span.director').html());
		$li.find('input.stars').val($li.find('span.stars').html());
		$li.find('textarea.review').val($li.find('span.review').html());
		$li.addClass('edit');
	});//close edit button
	
	$resultRegion.delegate('.cancelEdit','click',function(){
		$(this).closest('li').removeClass('edit');
	});//close canceledit button
	
	$resultRegion.delegate('.saveEdit','click',function(){
		var $li = $(this).closest('li');
		var film = {
			id: $li.find('input.id').val(),
			title: $li.find('input.title').val(),
			year: $li.find('input.year').val(),
			director: $li.find('input.director').val(),
			stars: $li.find('input.stars').val(),
			review: $li.find('input.review').val()
		}
		console.log(film);
		$.ajax({
			type: 'POST',
			url: 'UpdateFilm',
			data: film,
			success: function(request){
				$li.find('span.title').html(film.title);
				$li.find('span.year').html(film.year);
				$li.find('span.director').html(film.director);
				$li.find('span.stars').html(film.stars);
				$li.find('span.review').html(film.review);
				$li.removeClass('edit');
			},
			error: function(){
				alert('error updating film');
			}
		})
		
	});//close saveedit button
		
	
	
})//close function

function getValue(id) {
	return (escape(document.getElementById(id).value));
}//close function