function showJsonCustomerInfo(request,$resultRegion) {
  	if (request != null) {
    	var rawData = request;

		console.log(request);
    	var films = eval("(" + rawData + ")");
			//validating if a result was returned so an error msg can be shown if no result was found
			if(films.length >= 1){
				//iterates through records in the json object
		    	for(var i=0; i<films.length; i++) {
		      		var film = films[i];
					//creates an object to store the single film to pass to the mustache template
					var film_obj = {
						id: film.id,
						title: film.title,
						year: film.year,
						director: film.director,
						stars: film.stars,
						review: film.review,
						}//close film_obj
					//sends the film and the location to insert it to the method that will show the record to the user on the webpage
					addResult(film_obj, $resultRegion)	
					console.log("Search Complete, result returned");
				}
			}
			else{
				$resultRegion.html("<li> No Results Found with Search Values, Please Try again with a different Search</li>");
				console.log("Search Complete, No result found");
			}		
		}
  }


function showXmlCustomerInfo(request,$resultRegion) {
	//prints request for testing purposes
	//Checks if the request is populated, aka, has xml value within
	console.log("XML START");
  	if (request != null) {
		console.log(request);
		var films = request.getElementsByTagName("film");
		//validating if a result was returned so an error msg can be shown if no result was found
		if (films.length == 0){
			$resultRegion.html("<li> No Results Found with Search Values, Please Try again with a different Search</li>");
			console.log("Search Complete, No result found");
		}
		else{
	    	var rows = new Array();
	    	for(var i=0; i<films.length; i++) {
	      		var film = films[i];
	      		var subElements = ["id", "title", "year", "director","stars","review"];
	      		rows[i] = getElementValues(film, subElements);
				//creates a film object for mustache.js
				var film_obj = {
					id: rows[i][0],
					title: rows[i][1],
					year: rows[i][2],
					director: rows[i][3],
					stars: rows[i][4],
					review: rows[i][5],
					}//close film_obj
				//runs the function to insert the data into the webpage, passing the object and resultRegion
				addResult(film_obj, $resultRegion)
				console.log("Search Complete, result returned");
	    	}//close for loop
		}
  	}//close if
}//close function

function showStringCustomerInfo(request, $resultRegion) {
 	if (request != null) {
	    var rawData = request;
		console.log(rawData == "");
		if (rawData == ""){
			$resultRegion.html("<li> No Results Found with Search Values, Please Try again with a different Search</li>");
			console.log("Search Complete, No result found");
		} else {
	    var films = rawData.split(/\n+/);
		    for(var i=0; i<films.length; i++) {
				//validating if a result was returned so an error msg can be shown if no result was found
		      	if (films[i].length > 1) {  // Ignore blank lines
				var film_obj = {
						id: (films[i].split("|")[0]),
						title: (films[i].split("|")[1]),
						year: (films[i].split("|")[2]),
						director: (films[i].split("|")[3]),
						stars: (films[i].split("|")[4]),
						review: (films[i].split("|")[5]),
						}//close film_obj
				//sends the film and the location to insert it to the method that will show the record to the user on the webpage
				addResult(film_obj, $resultRegion)
				console.log("Search Complete, result returned");
				}
		      }//close if (2)
		    }//close for
		
	  }//close if (1)
}//close function

function addResult(film, $resultRegion){
	//collects the template from the html page
	var resultTemplate = $('#filmTemplate').html();
	//adds on a film record to the ul
	$resultRegion.append(Mustache.render(resultTemplate, film));
	
}