function All_CustomerTable($resultRegion, DataType){
	var format = DataType;
	if(format == "xml"){
		All_xmlCustomerTable($resultRegion);
	}
	else if(format == "string"){
		All_stringCustomerTable($resultRegion);
	}
	//default return is json
	else {
		All_jsonCustomerTable($resultRegion);
	}
}


function All_xmlCustomerTable(resultRegion) {
	console.log("XML TEST");
  	var address = "AllFilms";
	var data = makeParamString("","","xml");
  	$.ajax({	type: "GET",
			url: address, 
			data: data,
			success: function(request){showXmlCustomerInfo(request,resultRegion)},
			error: function(){
				alert('error running showXmlCustomerInfo()');
			}//close error function
		})//close ajax
}//close cuntion

function All_jsonCustomerTable($resultRegion) {
  	var address = "AllFilms";
	var data = makeParamString("","","json");
  	$.ajax({	type: "GET",
		url: address, 
		data: data,
		success: function(request){showJsonCustomerInfo(request,$resultRegion)},
		error: function(){
			alert('error running showJsonCustomerInfo()');
		}
	})//close ajax
}

function All_stringCustomerTable($resultRegion) {
  	var address = "AllFilms";
	var data = makeParamString("","","string");
  	$.ajax({	type: "GET",
		url: address, 
		data: data,
		success: function(request){showStringCustomerInfo(request,$resultRegion)},
		error: function(){
			alert('error running showJsonCustomerInfo()');
		}
	})//close ajax
}

